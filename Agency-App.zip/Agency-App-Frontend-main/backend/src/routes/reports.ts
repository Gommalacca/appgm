import { Router } from "express";
import passport from "passport";

import {
  createReport,
  getReport,
  getDailyReports,
  deleteReport,
  addDigitalSignature,
} from "../controllers/reports.controller";

import isModerator from "../middleware/company/isModerator";
import isWorker from "../middleware/company/isWorker";
import isAdvancedUser from "../middleware/company/isAdvancedUser"
const router: Router = Router();

router.get(
  "/daily",
  [passport.authenticate("jwt", { session: false }),isAdvancedUser, isWorker],
  getDailyReports
);

router.post(
  "/digitalSignature",
  [passport.authenticate("jwt", { session: false }),isAdvancedUser, isWorker],
  addDigitalSignature
);

router.post(
  "/",
  [passport.authenticate("jwt", { session: false }),isAdvancedUser,  isWorker],
  createReport
);

router.delete(
  "/:id",
  [passport.authenticate("jwt", { session: false }),  isModerator],
  deleteReport
);

router.get(
  "/:id",
  [passport.authenticate("jwt", { session: false }),isAdvancedUser,  isWorker],
  getReport
);

export = router;
