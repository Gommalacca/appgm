import express, { Router } from "express";
import isAdmin from "../middleware/user/isAdmin";
import passport from "passport";

import {
  getAllCompanies,
  getCompany,
  createCompany,
  deleteCompany,
  getEmployees,
  addEmployee,
  deleteEmployee,
  setModerator,
  deleteModerator,
  getProjects,
  getMonthlyReports,
  getMonthlyReportsWorkers,
  setAdvancedUser,
  getRecentReports,
  getRecentReportsWorker,
} from "../controllers/company.controller";

import isEmployee from "../middleware/company/isEmployee";
import isUserValidated from "../middleware/user/isUserValidated";
import isCompanyOwner from "../middleware/company/isCompanyOwner";
import isModerator from "../middleware/company/isModerator";
import isWorker from "../middleware/company/isWorker";
import { getUserHours } from "../controllers/users.controller";

const router: Router = express.Router();

router.get(
  "/hours/:userId",
  [passport.authenticate("jwt", { session: false })],
  getUserHours
);
router.get(
  "/projects",
  [passport.authenticate("jwt", { session: false }), isEmployee],
  getProjects
);

router.get(
  "/monthlyReport/:id",
  [passport.authenticate("jwt", { session: false }), isEmployee],
  getMonthlyReports
);

router.get(
  "/getMonthlyReportsWorkers/:id",
  [passport.authenticate("jwt", { session: false }), isWorker],
  getMonthlyReportsWorkers
);

router.get(
  "/recentReports",
  [passport.authenticate("jwt", { session: false }), isEmployee],
  getRecentReports
);

router.get(
  "/recentReportsWorkers",
  [passport.authenticate("jwt", { session: false }), isWorker],
  getRecentReportsWorker
);

router.get(
  "/employees",
  [passport.authenticate("jwt", { session: false }), isModerator],
  getEmployees
);

router.post(
  "/add-employee",
  [passport.authenticate("jwt", { session: false }), isModerator],
  addEmployee
);

router.post(
  "/delete-employee",
  [passport.authenticate("jwt", { session: false }), isModerator],
  deleteEmployee
);

// Get all companies
router.get(
  "/",
  [passport.authenticate("jwt", { session: false }), isAdmin],
  getAllCompanies
);

router.post(
  "/add-moderator",
  [
    passport.authenticate("jwt", { session: false }),
    isUserValidated,
    isCompanyOwner,
  ],
  setModerator
);

router.post(
  "/delete-moderator",
  [
    passport.authenticate("jwt", { session: false }),
    isUserValidated,
    isCompanyOwner,
  ],
  deleteModerator
);

router.post(
  "/advancedUser",
  [passport.authenticate("jwt", { session: false }), isModerator],
  setAdvancedUser
);

// Get company with id
router.get(
  "/:id",
  [passport.authenticate("jwt", { session: false }), isEmployee],
  getCompany
);

// Create new company
router.post(
  "/",
  [passport.authenticate("jwt", { session: false }), isUserValidated],
  createCompany
);

// Delete company
router.delete(
  "/:id",
  [
    passport.authenticate("jwt", { session: false }),
    isUserValidated,
    isCompanyOwner,
  ],
  deleteCompany
);

export = router;
