import { Router } from "express";
import passport from "passport";

import {
  getProject,
  createProject,
  deleteProject,
  modifyProject,
  getNotes,
  addNote,
  deleteNote,
  updateNote,
  addWorkers,
  getWorkers,
  deleteWorker,
  getHours,
  addHours,
  getCompanyProjects,
  editHours,
  getMonthlyWorkersProject,
  getDailyWorkersProject,
  deleteHours,
  getWorkerProject,
  addHoursWorker,
  deleteWorkerHours,
  fakeHoursDaily,
  getNotesDaily,
  getCompanyDailyProject,
  getWorkerProjectDaily,
} from "../controllers/projects.controller";

import isWorker from "../middleware/company/isWorker";
import isEmployee from "../middleware/company/isEmployee";
import isCompanyOwner from "../middleware/company/isCompanyOwner";
import isModerator from "../middleware/company/isModerator";
import isUserValidated from "../middleware/user/isUserValidated";
import isAdvancedUser from "../middleware/company/isAdvancedUser";

const router: Router = Router();

// Get project workers
router.post(
  "/monthlyWorkers",
  [passport.authenticate("jwt", { session: false }), isWorker],
  getMonthlyWorkersProject
);
router.get(
  "/dailyWorkers/:projectId",
  [passport.authenticate("jwt", { session: false }), isWorker],
  getDailyWorkersProject
);
router.get(
  "/workers/:projectId",
  [passport.authenticate("jwt", { session: false }), isWorker],
  getWorkers
);
router.post(
  "/worker",
  [passport.authenticate("jwt", { session: false }), isModerator],
  addWorkers
);
router.delete(
  "/worker",
  [passport.authenticate("jwt", { session: false }), isModerator],
  deleteWorker
);

router.get(
  "/hours/:projectId",
  [passport.authenticate("jwt", { session: false }), isWorker],
  getHours
);

router.post(
  "/hours",
  [passport.authenticate("jwt", { session: false }), isModerator],
  addHours
);

router.post(
  "/fakeHours",
  [passport.authenticate("jwt", { session: false }), isAdvancedUser, isWorker],
  fakeHoursDaily
);

router.post(
  "/workerHours",
  [passport.authenticate("jwt", { session: false }), isWorker],
  addHoursWorker
);

router.put(
  "/hours",
  [passport.authenticate("jwt", { session: false }), isWorker],
  editHours
);

router.delete(
  "/hours",
  [passport.authenticate("jwt", { session: false }), isModerator],
  deleteHours
);

router.delete(
  "/workerHours",
  [passport.authenticate("jwt", { session: false }), isWorker],
  deleteWorkerHours
);

router.post(
  "/note",
  [passport.authenticate("jwt", { session: false }), isEmployee],
  addNote
);

router.get(
  "/notes/:projectId",
  [passport.authenticate("jwt", { session: false }), isEmployee],
  getNotes
);

router.get(
  "/notes/:projectId/:date",
  [passport.authenticate("jwt", { session: false }), isEmployee],
  getNotesDaily
);

router.put(
  "/note",
  [passport.authenticate("jwt", { session: false }), isEmployee],
  updateNote
);
router.delete(
  "/note/:id",
  [passport.authenticate("jwt", { session: false }), isEmployee],
  deleteNote
);

// Get projects
router.get(
  "/",
  [passport.authenticate("jwt", { session: false }), isModerator],
  getCompanyProjects
);

// get daily project
router.get(
  "/daily/:date",
  [passport.authenticate("jwt", { session: false }), isModerator],
  getCompanyDailyProject
);

// get project where is worker
router.get(
  "/workerProject",
  [passport.authenticate("jwt", { session: false }), isWorker],
  getWorkerProject
);

router.get(
  "/workerProject/:date",
  [passport.authenticate("jwt", { session: false }), isWorker],
  getWorkerProjectDaily
);

// Get project by id
router.get(
  "/:id",
  [passport.authenticate("jwt", { session: false }), isEmployee, isWorker],
  getProject
);

// Create project
router.post(
  "/",
  [
    passport.authenticate("jwt", { session: false }),
    isUserValidated,
    isCompanyOwner,
  ],
  createProject
);

// Modify project
router.put(
  "/:id",
  [
    passport.authenticate("jwt", { session: false }),
    isUserValidated,
    isCompanyOwner,
  ],
  modifyProject
);

// Delete project
router.delete(
  "/:id",
  [
    passport.authenticate("jwt", { session: false }),
    isUserValidated,
    isCompanyOwner,
  ],
  deleteProject
);
export = router;
