import { Router } from "express";
import isAdmin from "../middleware/user/isAdmin";
import {
  getUser,
  getUsers,
  getUserInfo,
} from "../controllers/users.controller";
import passport from "passport";

const router: Router = Router();
router.get(
  "/info",
  [passport.authenticate("jwt", { session: false })],
  getUserInfo
);
router.get(
  "/",
  [passport.authenticate("jwt", { session: false }), isAdmin],
  getUsers
);
router.get(
  "/:id",
  [passport.authenticate("jwt", { session: false }), isAdmin],
  getUser
);

export = router;
