import { Router } from 'express';
import passport from 'passport';
import { changePassword, forgotPasswordToken, login, register, resetForgotPassword } from '../controllers/auth.controller';

const router: Router = Router();

router.post('/login', login);
router.post('/register', register);

// First need to setup smtp. or is dangerous
// router.post('/forgot-password', forgotPasswordToken);
// router.post('/reset-password/:token', resetForgotPassword);

router.post(
    '/change-password',
    passport.authenticate('jwt', { session: false }),
    changePassword
);

export = router;
