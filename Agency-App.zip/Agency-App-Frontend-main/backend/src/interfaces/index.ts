export interface IUser {
  id: string;
  role: string;
  valid: boolean;
  isStaff: boolean; // Global staff
  company: ICompany | undefined;
  employee: ICompany[] | undefined;
  projects: IProjectAssignment[] | undefined;
  firstname: string | undefined;
  lastname: string | undefined;
}

export interface IProjectAssignment {
  ProjectId: number;
}

interface IEmployeeAssignment {
  CompanyId: number;
  AdvancedUser: boolean;
}
export interface IProject {
  getCompany: () => ICompany;
  save: () => void;

  id: number;
  name: string;
  locality: string;
  digitalSignature: string;
  companyId: number;
  startAt: string;
}

export interface ICompany {
  id: number;
  ownerId: string;
  moderatorId: string;
  name: string;
  projectLimit: number;
  isStaff: boolean; // Company scope staff
  EmployeesAssignments: IEmployeeAssignment
}

export interface INote {
  destroy: () => void;
  getProjects: () => IProject;

  id: number;
  description: string;
  UserId: string;
  ProjectId: number;
}
export interface IWorker {
  id: number;
  firstname: string;
}
