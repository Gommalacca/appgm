import db from "./database/models";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import config from "./config/config";
import logging from "./config/logging";
import express, { NextFunction, Request, Response } from "express";
import RateLimit from "express-rate-limit";
import cookieParser from "cookie-parser";

import passport from "passport";
import loginMiddleware from "./middleware/passport/passport-login";
import jwtMiddleware from "./middleware/passport/passport-jwt";

import authRoutes from "./routes/auth";
import projectRoutes from "./routes/projects";
import usersRoutes from "./routes/users";
import companyRoutes from "./routes/company";
import reportsRoutes from "./routes/reports";

// Seeder ( db auto generated data)
import {
  generateCompany,
  generateEmployee,
  generateProject,
  generateUsers,
  generateWorker,
} from "./database/seeders/seeder";

const router = express();
const NAMESPACE = "Server";

const limiter = RateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10000, // limit each IP to 100 requests per windowMs
});

// Security || Uility Middleware
router.use(cors({ origin: "*" }));
router.use(cookieParser());
router.set("trust proxy", true);
router.use(limiter);
router.use(express.urlencoded({ extended: false }));
router.use(express.json());
router.use(helmet());
router.use(morgan("dev"));

// Initialize passport and passport middlewares
router.use(passport.initialize());
passport.use("login", loginMiddleware);
passport.use("jwt", jwtMiddleware);

// Setup routes
router.use("/auth", authRoutes);
router.use("/user", usersRoutes);
router.use("/project", projectRoutes);
router.use("/company", companyRoutes);
router.use("/reports", reportsRoutes);

// Log requests
router.use((req: Request, res: Response, next: NextFunction) => {
  res.on("finish", () => {
    logging.info(
      NAMESPACE,
      `Method - [${req.method}], URL - [${req.url}], IP - [${req.ip}],  STATUS - [${res.statusCode}]`
    );
  });
  next();
});

// Err 400 handling
router.use((err: Error, req: Request, res: Response, next: NextFunction) => {
  if (!err) return next();
  return res.status(400).json({
    status: 400,
    error: "OOps! Bad request",
  });
});

// Err 404 handling
router.use((req: Request, res: Response) => {
  const error = new Error("Route not found");
  return res.status(404).json({
    message: "Invalid route",
  });
});

async function init() {
  try {
    // Sync db
    config.server.database.forceReset === "true" &&
    config.server.env === "development"
      ? await db.sequelize.sync({ force: true })
      : await db.sequelize.sync();

    if (
      config.server.database.autoFill === "true" &&
      config.server.env === "development"
    ) {
      await generateUsers();
      await generateCompany();
      await generateProject();
      // await generateEmployee();
      // await generateWorker();
    }
    router.listen(port, () =>
      console.log(`Running on port ${port} | env : ${config.server.env}`)
    );
  } catch (error) {
    return error;
  }
}

init();

const port = config.server.port;
