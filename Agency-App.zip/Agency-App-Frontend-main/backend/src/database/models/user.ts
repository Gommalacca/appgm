'use strict';
import { Model, UUIDV4 } from 'sequelize';
import bcrypt from 'bcrypt';

interface UserAttributes {
  id: string;
  tag: string;
  firstname: string;
  lastname: string;
  password: string;
  email: string;
  role: string;
  valid: boolean;
  reset_password_token: string;
  reset_password_time: number;
}

module.exports = (sequelize: any, DataTypes: any) => {
  class User extends Model<UserAttributes> implements UserAttributes {
    id!: string;
    tag!: string;
    username!: string;
    password!: string;
    email!: string;
    firstname!: string;
    lastname!: string;
    role!: string;
    valid!: boolean;
    reset_password_token!: string;
    reset_password_time!: number;

    generatePassword!: (password: string) => Promise<User>;
    verifyPassword!: (password: string) => Promise<boolean>;

    toJSON() {
      return {
        ...this.get(),
        password: undefined,
        reset_password_token: undefined,
        reset_password_time: undefined
      };
    }

    static associate(models: any) {
      User.hasOne(models.Companies, {
        as: 'owner',
        foreignKey: "ownerId"
      })

      User.hasOne(models.Companies, {
        as: 'moderator',
        foreignKey: "moderatorId"
      })

      User.belongsToMany(models.Companies, {
        as: 'employee',
        through: "EmployeesAssignments"
      })

      User.belongsToMany(models.Projects, {
        through: 'ProjectAssignments'
      });
      User.hasMany(models.Hours);

    }
  }
  User.init(
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: UUIDV4,
        primaryKey: true,
        allowNull: false,
        unique: true
      },
      tag: {
        type: DataTypes.STRING,
        allowNull: true,
        unique: true
      },
      password: {
        type: DataTypes.STRING,
        allowNull: false
      },
      email: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
      },
      firstname: {
        type: DataTypes.STRING,
        allowNull: false
      },
      lastname: {
        type: DataTypes.STRING,
        allowNull: false
      },
      valid: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
        allowNull: false
      },
      role: {
        type: DataTypes.STRING,
        defaultValue: 'user'
      },
      reset_password_token: {
        type: DataTypes.STRING,
        allowNull: true
      },
      reset_password_time: {
        type: DataTypes.BIGINT,
        allowNull: true
      }
    },
    {
      sequelize,
      modelName: 'Users',
      paranoid: true,
      hooks: {
        beforeCreate: (user) => {
          const salt = bcrypt.genSaltSync();
          const randomID = Math.random().toString(36).substr(2, 9);
          user.tag = `${user.firstname}#${randomID}`;
          user.password = bcrypt.hashSync(user.password, salt);
        }
      }
    }
  );

  User.prototype.generatePassword = async function (password: string) {
    const salt = bcrypt.genSaltSync();
    this.password = bcrypt.hashSync(password, salt);
    return await this.save();
  };

  User.prototype.verifyPassword = async function (password: string) {
    return await bcrypt.compare(password, this.password);
  };

  return User;
};
