"use strict";
import { Model } from "sequelize";

interface HoursAttributes {
  ProjectId: number;
  Hours: number;
}

module.exports = (sequelize: any, DataTypes: any) => {
  class Hours extends Model<HoursAttributes> implements HoursAttributes {
    Hours!: number;
    ProjectId!: number;

    static associate(models: any) {
      Hours.belongsTo(models.Users);
      Hours.belongsTo(models.Projects);
      Hours.belongsTo(models.Companies);
    }
  }

  Hours.init(
    {
      Hours: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      ProjectId: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
    },
    {
      sequelize,
      modelName: "Hours",
    }
  );
  return Hours;
};
