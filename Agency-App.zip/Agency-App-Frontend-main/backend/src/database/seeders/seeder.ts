import db from '../models';
import { users, companies, projects, workers, employees } from './seederDb';

import logging from '../../config/logging';

export const generateUsers = () => {
    users.map(async (user: any) => {
        try {
            const _user = await db.Users.create(user);
            if (!_user) {
                logging.info("SEEDER", "User already exist");
                return;
            }
        }catch (error: Error | any) {
            if (error instanceof Error) {
              logging.info("SEEDER", error.message);
            }else{
            logging.info("SEEDER", error);
            }
        }
    });
};

export const generateCompany = () => {
    companies.map(async (company) => {
        try {
            await db.Companies.create(company);
        } catch (error: Error | any) {
            if (error instanceof Error) {
              logging.info("SEEDER", error.message);
            }else{
            logging.info("SEEDER", error);
            }
        }
    });
}

export const generateProject = () => {
    projects.map(async (project: any) => {
        try {
            await db.Projects.create(project);
        } catch (error: Error | any) {
            if (error instanceof Error) {
              logging.info("SEEDER", error.message);
            }else{
            logging.info("SEEDER", error);
            }
        }
    });
}

export const generateEmployee = () => {
    employees.map(async (employee: any) => {
        try {
            await db.EmployeesAssignments.create(employee);
        } catch (error: Error | any) {
            if (error instanceof Error) {
              logging.info("SEEDER", error.message);
            }else{
            logging.info("SEEDER", error);
            }
        }
    });
}

export const generateWorker = () => {
    workers.map(async (worker: any) => {
        try {
            await db.ProjectAssignments.create(worker);
        } catch (error: Error | any) {
            if (error instanceof Error) {
              logging.info("SEEDER", error.message);
            }else{
            logging.info("SEEDER", error);
            }
        }
    });
}