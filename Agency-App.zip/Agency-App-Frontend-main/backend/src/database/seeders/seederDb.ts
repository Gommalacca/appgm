export const users = [
  {
    id: "9d3e7c64-c7ba-4b24-a13a-52364f774006",
    email: "nick@email.it",
    firstname: "Admin",
    lastname: "admin",
    valid: false,
    role: "admin",
    deletedAt: null,
    password: "Test123456!",
  },
  {
    id: "466f8ce4-67d7-4d15-9b41-206e5e43e0ef",
    email: "giacomo@email.it",
    firstname: "giacomo",
    lastname: "user",
    valid: true,
    role: "user",
    password: "gmImpianti1234!",
  },
];

// import { users, companies,projects, companies, workers } from './seederDb';

export const companies = [
  {
    ownerId: "466f8ce4-67d7-4d15-9b41-206e5e43e0ef",
    projectsLimit: 5,
    name: "GM Impianti",
    locality: "Lucca",
    companyId: 1,
  },
];

export const projects = [
  {
    name: "Project",
    locality: "Lucca",
    companyId: 1,
  },
];

export const employees = [
  {
    CompanyId: 1,
    UserId: "466f8ce4-67d7-4d15-9b41-206e5e43e0ef",
  },
];

export const workers = [
  {
    ProjectId: 1,
    UserId: "466f8ce4-67d7-4d15-9b41-206e5e43e0ef",
  },
];
