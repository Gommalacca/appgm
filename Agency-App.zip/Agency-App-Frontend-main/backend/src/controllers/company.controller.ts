import { Request, Response } from "express";
import logging from "../config/logging";
import JsonValidator from "../schemas/companies";
import db from "../database/models";
import { IUser, ICompany } from "../interfaces";
import { Op } from "sequelize";
const NAMESPACE = "COMPANY - CONTROLLER";

interface ICompanyCreate {
  name: string;
  projectsLimit: number;
  ownerId: string;
}

export const getAllCompanies = async (req: Request, res: Response) => {
  try {
    const companies = await db.Companies.findAll();
    if (!companies) {
      return res.status(400).json({
        message: "Ops, no companies found",
      });
    }
    return res.status(200).json(companies);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops, some error occurred",
    });
  }
};

export const getCompany = async (req: Request, res: Response) => {
  try {
    const companyId: number = parseInt(req.params.id);
    const user: IUser | undefined = req.user;
    if (user === undefined)
      return res.status(401).json({ message: "Must be logged in!" });
    if (user.employee === null || user.employee === undefined)
      return res.status(401).json({ message: "You aren't an employee" });

    if (user.employee.length > 0 && companyId !== user.company?.id) {
      const company = await user.employee.filter((company: ICompany) => {
        return company.id === companyId;
      });
      if (company.length === 0 || company === null) {
        return res.status(401).json({
          message: "Unauthorized!",
        });
      }
      user.company = company[0];
    }

    if (companyId !== user.company?.id && !user.isStaff) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const company = await db.Companies.findOne({
      where: { id: companyId },
    });
    if (!company) {
      return res.status(400).json({
        message: "No company found with this id",
      });
    }

    return res.status(200).json(company);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops, some error occurred",
    });
  }
};

export const createCompany = async (req: Request, res: Response) => {
  if (req.user == undefined) {
    return res.status(401).json({
      message: "Unauthorized",
    });
  }

  const validator = JsonValidator.createCompany;
  const validation = validator(req.body);

  if (!validation) {
    if (!validator.errors) {
      logging.info(NAMESPACE, "Some error with create company validator");
      return res.status(500).json({
        message: "Internal server error",
      });
    } else {
      return res.status(400).json({
        message: validator.errors[0].message,
      });
    }
  }

  try {
    var payload: ICompanyCreate = {
      ownerId: req.user.id,
      name: req.body.name,
      projectsLimit: req.body.projectsLimit,
    };

    const company = await db.Companies.create(payload);
    if (!company) {
      return res.status(400).json({
        message: "Company already exist!",
      });
    }
    return res.status(200).json({
      message: company,
      user: company.user,
    });
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json(error.errors[0].message);
  }
};

export const deleteCompany = async (req: Request, res: Response) => {
  try {
    if (req.params.id === "")
      return res.status(400).json({ message: "Missing id" });
    const companyId: number = parseInt(req.params.id);

    const company = await db.Companies.destroy({
      where: { id: companyId },
    });
    if (!company) {
      return res.status(400).json({
        message: "Company not found!",
      });
    }
    return res.status(200).json({
      message: "Company deleted",
    });
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "OPS, some error occurred",
    });
  }
};

export const getEmployees = async (req: Request, res: Response) => {
  try {
    const company = await db.Companies.findOne({
      where: { id: req.user?.company?.id },
      exclude: ["email", "valid", "role", "deletedAt"],
    });
    if (!company) {
      return res.status(400).json({
        message: "No company found with this id",
      });
    }
    var employees = await company.getEmployee({
      exclude: ["UserId", "createdAt", "updatedAt"],
      include: ["moderator"],
    });
    return res.status(200).json(employees);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops, some error occurred",
    });
  }
};

export const addEmployee = async (req: Request, res: Response) => {
  try {
    const { employeeId } = req.body;
    if (typeof employeeId !== "string")
      return res.status(400).json({ message: "Bad data!" });
    if (req.user?.company?.ownerId === employeeId)
      return res.status(400).json({ message: "Owner can't be an employee" });
    const user = await db.Users.findOne({ where: { id: employeeId } });
    if (!user) {
      return res.status(400).json({
        message: "No User found with this id",
      });
    }
    const company = await db.Companies.findOne({
      where: { id: req.user?.company?.id },
    });

    if (!company) {
      return res.status(400).json({
        message: "No company found with this id",
      });
    }

    const employees = await company.addEmployee(user);
    if (!employees) {
      return res.status(400).json({
        message: "Ops, Assignment already exist",
      });
    }
    return res.status(200).json(employees);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops, some error occurred",
    });
  }
};

export const deleteEmployee = async (req: Request, res: Response) => {
  try {
    const { employeeId } = req.body;
    if (typeof employeeId !== "string")
      return res.status(400).json({ message: "Bad data!" });

    const user = await db.Users.findOne({ where: { id: employeeId } });
    if (!user) {
      return res.status(400).json({
        message: "No user found with this id",
      });
    }

    const company = await db.Companies.findOne({
      where: { id: req.user?.company?.id },
    });

    if (!company) {
      return res.status(400).json({
        message: "No company found with this id",
      });
    }

    const employees = await company.removeEmployee(user);
    if (!employees) {
      return res.status(400).json({
        message: "Ops, assignment doesn't exist",
      });
    }
    return res.status(200).json(employees);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops, some error occurred",
    });
  }
};

export const setModerator = async (req: Request, res: Response) => {
  try {
    const { userId } = req.body;
    if (typeof userId !== "string")
      return res.status(400).json({ message: "Bad data!" });

    const user = await db.Users.findOne({ where: { id: userId } });

    if (!user) {
      return res.status(400).json({
        message: "No user found with this id",
      });
    }
    if (!req.user?.company) {
      return res.status(404).json({ message: "Unauthorized" });
    }
    const company = await db.Companies.findOne({
      where: { id: req.user?.company?.id },
    });

    if (!company) {
      return res.status(400).json({
        message: "No company found with this id",
      });
    }

    const moderator = await company.setModerator(user);
    return res.status(200).json(moderator);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops, some error occurred",
    });
  }
};

export const deleteModerator = async (req: Request, res: Response) => {
  try {
    const { userId } = req.body;
    if (typeof userId !== "string")
      return res.status(400).json({ message: "Bad data!" });

    const user = await db.Users.findOne({ where: { id: userId } });

    if (!user) {
      return res.status(400).json({
        message: "No user found with this id",
      });
    }

    const company = await db.Companies.findOne({
      where: { id: req.user?.company?.id },
    });

    if (!company) {
      return res.status(400).json({
        message: "No company found with this id",
      });
    }

    const moderator = await company.setModerator(null);
    return res.status(200).json(moderator);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops, some error occurred",
    });
  }
};

export const setAdvancedUser = async (req: Request, res: Response) => {
  try {
    const { userId } = req.body;
    if (typeof userId !== "string")
      return res.status(400).json({ message: "Bad data!" });

    const user = await db.Users.findOne({ where: { id: userId } });

    if (!user) {
      return res.status(400).json({
        message: "No user found with this id",
      });
    }
    if (!req.user?.company) {
      return res.status(404).json({ message: "Unauthorized" });
    }
    const company = await db.Companies.findOne({
      where: { id: req.user?.company?.id },
    });

    if (!company) {
      return res.status(400).json({
        message: "No company found with this id",
      });
    }

    const employee = await company.getEmployee({
      where: {
        id: user.id,
      },
      includes: ["EmployeesAssignments"],
    });
    if (employee.length === 0)
      return res
        .status(400)
        .json({ message: "No employee found with this id" });
    const updatedReport = await employee[0].EmployeesAssignments.update({
      AdvancedUser: !employee[0].EmployeesAssignments.AdvancedUser,
    });

    return res.status(200).json(updatedReport);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops, some error occurred",
    });
  }
};

export const getProjects = async (req: Request, res: Response) => {
  try {
    const company = await db.Companies.findOne({
      where: { id: req.user?.company?.id },
    });
    if (!company) {
      return res.status(400).json({
        message: "No company found with this id",
      });
    }
    const projects = await company.getProjects();
    return res.status(200).json(projects);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops, some error occurred",
    });
  }
};

export const getRecentReports = async (req: Request, res: Response) => {
  try {
    const hours = await db.Hours.findAll({
      order: [["createdAt", "DESC"]],
      include: [
        {
          model: db.Users,
          required: true,
        },
        {
          model: db.Projects,
          required: true,
        },
      ],
    });

    res.send(hours);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops, some error occurred",
    });
  }
};

export const getRecentReportsWorker = async (req: Request, res: Response) => {
  try {
    const _user: IUser | undefined = req.user;
    if (!_user)
      return res.status(401).json({
        message: "You aren't logged in",
      });
    const user = await db.Users.findOne({
      attributes: ["id", "firstname", "lastname", "tag"],
      where: { id: _user.id },
    });
    const hours = await user.getHours({
      order: [["createdAt", "DESC"]],
      include: [
        {
          model: db.Users,
          required: true,
        },
        {
          model: db.Projects,
          required: true,
        },
      ],
    });
    if (hours.length == 0) return res.status(200).json([]);

    res.send(hours);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops, some error occurred",
    });
  }
};

export const getMonthlyReports = async (req: Request, res: Response) => {
  try {
    if (req.params.id === "")
      return res.status(400).json({ message: "Missing id" });

    const _month: number = parseInt(req.params.id);
    var date = new Date(),
      y = date.getFullYear(),
      m = _month;
    var firstDay = new Date(y, m, 1);
    var lastDay = new Date(y, m + 1, 0);

    const companyId = req.user?.company?.id;
    const company = await db.Companies.findOne({
      where: { id: companyId },
    });
    const employees = await company.getEmployee({
      attributes: ["id", "firstname", "lastname", "tag"],
      include: [
        {
          attributes: ["id", "Hours", "ProjectId"],
          model: db.Hours,
          required: true,
          where: {
            createdAt: {
              [Op.between]: [firstDay, lastDay],
            },
          },
        },
      ],
    });
    res.send(employees);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops, some error occurred",
    });
  }
};

export const getMonthlyReportsWorkers = async (req: Request, res: Response) => {
  try {
    if (req.params.id === "")
      return res.status(400).json({ message: "Missing id" });
    const _month: number = parseInt(req.params.id);
    var date = new Date(),
      y = date.getFullYear(),
      m = _month;
    var firstDay = new Date(y, m, 1);
    var lastDay = new Date(y, m + 1, 0);

    const _user: IUser | undefined = req.user;
    if (!_user)
      return res.status(401).json({
        message: "You aren't logged in",
      });
    const user = await db.Users.findOne({
      attributes: ["id", "firstname", "lastname", "tag"],
      where: { id: _user.id },
    });
    const hours = await user.getHours({
      where: {
        createdAt: {
          [Op.between]: [firstDay, lastDay],
        },
      },
    });
    if (hours.length == 0) return res.status(200).json([]);
    let pick = (({ firstname, lastname, tag, id }) => ({
      firstname,
      lastname,
      tag,
      id,
    }))(user);
    let obj = {
      ...pick,
      Hours: hours,
    };

    res.send(obj);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops, some error occurred",
    });
  }
};
