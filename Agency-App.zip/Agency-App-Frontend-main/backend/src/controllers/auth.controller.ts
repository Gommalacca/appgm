import { Op } from "sequelize";
import { pool } from "../database/config/pool.connector";
import passport from "passport";
import { sign, SignOptions } from "jsonwebtoken";
import { RateLimiterPostgres } from "rate-limiter-flexible";
import { timingSafeEqual, randomBytes } from "crypto";
import { NextFunction, Request, Response } from "express";

import db from "../database/models";
import config from "../config/config";
import logging from "../config/logging";
import JsonValidator from "../schemas/users";

interface IUserRegistration {
  firstname: string;
  lastname: string;
  email: string;
  password: string;
}

const NAMESPACE = "AUTH - CONTROLLER";

const maxWrongAttemptsByIPperDay = 50;
const maxConsecutiveFailsByEmailAndIP = 50;

const limiterSlowBruteByIP = new RateLimiterPostgres({
  storeClient: pool,
  keyPrefix: "login_fail_ip_per_day",
  points: maxWrongAttemptsByIPperDay,
  duration: 60 * 60 * 24,
  blockDuration: 60 * 60 * 24, // Block for 1 day, if 100 wrong attempts per day
});
const limiterConsecutiveFailsByEmailAndIP = new RateLimiterPostgres({
  storeClient: pool,
  keyPrefix: "login_fail_consecutive_email_and_ip",
  points: maxConsecutiveFailsByEmailAndIP,
  duration: 60 * 60 * 24 * 90, // Store number for 90 days since first fail
  blockDuration: 60 * 60, // Block for 1 hour
});

const getEmailIPkey = (email: string, ip: string): string => `${email}_${ip}`;

export const register = async (req: Request, res: Response) => {
  const validator = JsonValidator.register;
  const validation = validator(req.body);

  if (!validation) {
    if (!validator.errors) {
      logging.info(NAMESPACE, "Some error with register validator");
      return res.status(500).json({
        message: "Internal server error",
      });
    } else {
      return res.status(400).json({
        message: validator.errors[0].message,
      });
    }
  }
  const userRegistrationData: IUserRegistration = req.body;

  try {
    const user = await db.Users.create(userRegistrationData);
    if (user) {
      return res.status(200).json(user);
    }
    return res.status(500).json({
      message: "Internal server error",
    });
  } catch (error: Error | any) {
    if (error instanceof Error) {

      return res.status(400).json({
        message: error.message,
      });

    } else {
      return res.status(400).json({
        message: "Internal server error",
      });
    }
  };
};

export const login = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const validator = JsonValidator.login;
  const validation = validator(req.body);
  if (!validation) {
    if (!validator.errors) {
      logging.info(NAMESPACE, "Some error with login validator");
      return res.status(500).json({
        message: "Internal server error",
      });
    } else {
      return res.status(400).json({
        message: validator.errors[0].message,
      });
    }
  }
  const ipAddr = req.ip;
  const emailIPkey = getEmailIPkey(req.body.email, ipAddr);
  const resEmailAndIP = await limiterConsecutiveFailsByEmailAndIP.get(
    emailIPkey
  );
  const resSlowByIP = await limiterSlowBruteByIP.get(ipAddr);
  var retrySecs = 0;
  // Check if IP or Email + IP is already blocked
  if (
    resSlowByIP !== null &&
    resSlowByIP.consumedPoints > maxWrongAttemptsByIPperDay
  ) {
    retrySecs = Math.round(resSlowByIP.msBeforeNext / 1000) || 1;
  } else if (
    resEmailAndIP !== null &&
    resEmailAndIP.consumedPoints > maxConsecutiveFailsByEmailAndIP
  ) {
    retrySecs = Math.round(resEmailAndIP.msBeforeNext / 1000) || 1;
  }
  if (retrySecs > 0) {
    res.set("Retry-After", String(retrySecs));
    return res.status(500).json({
      message: "Too many request",
    });
  }

  try {
    const promises = [limiterSlowBruteByIP.consume(ipAddr)];
    passport.authenticate("login", { session: false }, async (err: Error, user:any) => {
      try {
        if (err) {
          return res.status(500).json({
            message: "New error occurred",
          });
        }

        if (!user) {
          // Push login token
          promises.push(
            limiterConsecutiveFailsByEmailAndIP.consume(emailIPkey)
          );
          // Resolve promise
          await Promise.all(promises).catch((e) => { });

          return res.status(400).json({
            message: "Wrong credentials",
          });
        }
        req.login(user, { session: false }, async (error: Error) => {
          if (error) return res.status(500).json({ message: error.message });
          // Create jwt payload
          const jwtBody: {
            id: string;
            role: string;
          } = {
            id: user.user.id,
            role: user.user.role,
          };
          // jwt token options
          const jwtOpts: SignOptions = {
            issuer: config.server.token.issuer,
            algorithm: "HS256",
            expiresIn: "6h",
          };

          // Create token
          const token = await sign(
            jwtBody,
            config.server.token.secret,
            jwtOpts
          );
          if (resSlowByIP !== null && resSlowByIP.consumedPoints > 0) {
            // Reset on successful authorisation
            await limiterSlowBruteByIP.delete(ipAddr);
          }
          let _user = user.user;
          let company = user.company;
          return res.status(200).json({ token, user: _user, company });
        });
      } catch (error: Error | any) {
        if (error instanceof Error) {

          return res.status(500).json({
            message: error.message,
          });

        } else {
          return res.status(500).json({
            message: "Internal server error",
          });
        }
      };
    }) (req, res);
} catch (rlRejected: Error | any) {
  if (rlRejected instanceof Error) {
    logging.error(NAMESPACE, rlRejected.message, rlRejected);
    return res.status(500).json({
      message: "Ops, some error occurred",
    });
  } else {
    // Set headers (avoid spam)
    res.set(
      "Retry-After",
      String(Math.round(rlRejected.msBeforeNext / 1000)) || "1"
    );
    return res.status(429).json({
      message: "Too Many Requests",
    });
  }
}
};

export const changePassword = async (req: Request, res: Response) => {
  const validator = JsonValidator.changePassword;
  const validation = validator(req.body);

  if (!validation) {
    if (!validator.errors) {
      logging.info(NAMESPACE, "Some error with change password validator");
      return res.status(500).json({
        message: "Internal server error",
      });
    } else {
      return res.status(400).json({
        message: validator.errors[0].message,
      });
    }
  }
  const { oldPassword, newPassword } = req.body;

  if (oldPassword === newPassword) {
    return res.status(400).json({
      message: "Don't set the same password!",
    });
  }

  if (req.user === undefined || req.user === null)
    return res.status(401).json({ message: "Must be logged in" });
  const _user = req.user;

  try {
    const user = await db.Users.findOne({ _user });
    if (!user) {
      return res.status(400).json({
        message: "User not found",
      });
    }
    const validatePassword = await user.verifyPassword(oldPassword);
    if (!validatePassword) {
      return res.status(400).json({ message: "Wrong Password" });
    }

    const newUser = await user.generateNewPassword(newPassword);
    if (!newUser) {
      return res.status(500).json({
        message: "Some error occurred while setting new password",
      });
    }

    return res.status(200).json(newUser);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);

      return res.status(500).json({
        message: error.message,
      });

    } else {
      return res.status(500).json({
        message: "Internal server error",
      });
    }
  };
};

export const forgotPasswordToken = async (req: Request, res: Response) => {
  const validator = JsonValidator.getTokenPassword;
  const validation = validator(req.body);

  if (!validation) {
    if (!validator.errors) {
      logging.info(NAMESPACE, "Some error with set operator validator");
      return res.status(500).json({
        message: "Internal server error",
      });
    } else {
      return res.status(400).json({
        message: validator.errors[0].message,
      });
    }
  }
  const email = req.body.email;
  try {
    const user = await db.Users.findOne({ where: { email: email } });

    if (!user) {
      return res.status(400).json({
        message: "No user found",
      });
    }

    const token = await randomBytes(20).toString("hex");
    user.reset_password_token = token;
    user.reset_password_time = Date.now() + 3600000;

    await user
      .save()
      .then(() => {
        const message = `http://${req.headers.host}/password-reset/${token} - 1 HR`;
        res.status(200).json({
          message: message,
        });
      })
      .catch((error: Error) => {
        logging.info(NAMESPACE, error.message);
        return res.status(500).json({
          message: "Some error occurred",
        });
      });
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Some error occurred",
    });
  }
};

export const resetForgotPassword = async (req: Request, res: Response) => {
  const { password } = req.body;
  const validator = JsonValidator.resetPassword;
  const validation = validator(req.body);

  if (!validation) {
    if (!validator.errors) {
      logging.info(NAMESPACE, "Some error with reset password validator");
      return res.status(500).json({
        message: "Internal server error",
      });
    } else {
      return res.status(400).json({
        message: validator.errors[0].message,
      });
    }
  }

  try {
    const user = await db.Users.findOne({
      where: {
        [Op.and]: [
          {
            reset_password_time: {
              [Op.gt]: Date.now(),
            },
            reset_password_token: req.params.token,
          },
        ],
      },
    });

    if (
      user.reset_password_token == null ||
      user.reset_password_token == undefined
    ) {
      return res.status(401).json({
        message: "No token avaiable",
      });
    }

    if (!user) {
      res.status(400).json({ message: "No user found" });
    }
    if (
      !timingSafeEqual(
        Buffer.from(user.reset_password_token),
        Buffer.from(req.params.token)
      )
    ) {
      return res.status(401).json({ message: "Token expired" });
    }

    user.reset_password_time = null;
    user.reset_password_token = null;

    const newUser = await user.generateNewPassword(password);
    if (!newUser) {
      return res.status(400).json({ message: "Wrong Password" });
    }

    return res.status(200).send(newUser);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    res.status(500).json({
      message: "Some error occurred!",
    });
  }
};
