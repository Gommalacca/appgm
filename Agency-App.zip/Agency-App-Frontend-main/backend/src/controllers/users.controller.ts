import { Request, Response } from "express";
import logging from "../config/logging";
import db from "../database/models";
import { IUser } from "../interfaces";

const NAMESPACE = "USERS - CONTROLLER";

export const getUsers = async (req: Request, res: Response) => {
  try {
    const users = await db.Projects.findAll();

    return res.status(200).json(users);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops! some error occurred",
    });
  }
};

export const getUser = async (req: Request, res: Response) => {
  try {
    const userID = req.params.id;
    const user = await db.Users.findOne({ where: { id: userID } });
    if (!user) {
      return res.status(400).json({
        message: "User not found",
      });
    }

    return res.status(200).json(user);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops! some error occurred",
    });
  }
};

export const getUserInfo = (req: Request, res: Response) => {
  try {
    const user: IUser | undefined = req.user;

    if (user === undefined || user === null) {
      return res.status(401).json({
        message: "Must be logged in!",
      });
    }
    return res.status(200).json(user);
  } catch (error) {
    return res.status(500).json({
      message: "Ops, some error occurred!",
    });
  }
};

export const getUserHours = async (req: Request, res: Response) => {
  try {
    const userId: string = req.params.userId;
    const user: IUser | undefined = req.user;

    if (user === undefined || user === null) {
      return res.status(401).json({
        message: "Must be logged in!",
      });
    }

    const _user = await db.Users.findOne({
      where: { id: userId },
      include: [
        {
          model: db.Hours,
          required: true,
          include: [
            {
              model: db.Projects,
              required: true,
            },
          ],
        },
      ],
    });

    return res.status(200).json(_user);
  } catch (error) {
    return res.status(500).json({
      message: "Ops, some error occurred!",
    });
  }
};
