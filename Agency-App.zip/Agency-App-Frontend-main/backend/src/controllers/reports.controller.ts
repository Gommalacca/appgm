import { Request, Response } from "express";
import { Op } from "sequelize";
import logging from "../config/logging";
import db from "../database/models";
const NAMESPACE = "REPORTS - CONTROLLER";

interface Hour {
  id: number;
  Hours: number;
  ProjectId: number;
  createdAt: Date;
  updatedAt: Date;
  UserId: string;
  CompanyId: number;
}

interface User {
  id: string;
  firstname: string;
  lastname: string;
  Hours: Hour[];
}

export const createReport = async (req: Request, res: Response) => {
  try {
    const projectId: number = req.body.projectId;
    const workers: User[] = req.body.workers;
    const digitalSignature: string | null = req.body.digitalSignature;

    const project = await db.Projects.findOne({
      where: { id: projectId },
    });
    if (!project)
      return res
        .status(400)
        .json({ message: "No projects found with this id!" });

    const _report = await db.Reports.create({
      projectId: project.id,
      projectName: project.name,
      workers: workers,
      digitalSignature: digitalSignature,
    });
    console.log(_report);
    res.status(200).json(_report);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    res.status(500).json({
      message: "Ops some error occurred!",
    });
  }
};
export const getDailyReports = async (req: Request, res: Response) => {
  try {
    const TODAY_START = new Date().setHours(0, 0, 0, 0);
    const NOW = new Date();

    const reports = await db.Reports.findAll({
      where: {
        createdAt: {
          [Op.gt]: TODAY_START,
          [Op.lt]: NOW,
        },
      },
      order: [["createdAt", "DESC"]],
    });
    res.send(reports);
  }  catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    res.status(500).json({
      message: "Ops some error occurred!",
    });
  }
};

export const getReport = async (req: Request, res: Response) => {
  try {
    const reportId = parseInt(req.params.id);
    const TODAY_START = new Date().setHours(0, 0, 0, 0);
    const NOW = new Date();
    const reports = await db.Reports.findAll({
      where: {
        [Op.and]: [
          {
            createdAt: {
              [Op.gt]: TODAY_START,
              [Op.lt]: NOW,
            },
          },
          {
            id: reportId,
          },
        ],
      },
    });
    res.send(reports);
  }  catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    res.status(500).json({
      message: "Ops some error occurred!",
    });
  }
};

export const deleteReport = async (req: Request, res: Response) => {
  try {
    const reportId = parseInt(req.params.id);
    const destroy = await db.Reports.destroy({
      where: { id: reportId },
    });
    return res.status(200).json(destroy);
  }  catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    res.status(500).json({
      message: "Ops some error occurred!",
    });
  }
};

export const addDigitalSignature = async (req: Request, res: Response) => {
  try {
    const reportID: number = parseInt(req.body.reportId);
    const digitalSignature: string = req.body.digitalSignature;
    const report = await db.Reports.findByPk(reportID);
    const updatedReport = await report.update({
      digitalSignature: digitalSignature,
    });
    res.send(updatedReport);
  }  catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    res.status(500).json({
      message: "Ops some error occurred!",
    });
  }
};
