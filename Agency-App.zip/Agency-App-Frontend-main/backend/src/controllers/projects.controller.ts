import { Request, Response } from "express";
import { IUser, IProject, INote } from "interfaces";
import { Op } from "sequelize";
import Models from "../database/models";
import logging from "../config/logging";
import db from "../database/models";

const NAMESPACE = "PROJECTS - CONTROLLER";

export const getCompanyProjects = async (req: Request, res: Response) => {
  try {
    const company = await db.Companies.findOne({
      where: { id: req.user?.company?.id },
      include: "projects",
    });
    return res.status(200).json(company.projects);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops! some error occurred",
    });
  }
};

export const getCompanyDailyProject = async (req: Request, res: Response) => {
  try {
    const date: string = req.params.date;
    const TODAY_START = new Date(date).setHours(0, 0, 0, 0);
    const NOW = new Date(date);
    const company = await db.Companies.findOne({
      where: { id: req.user?.company?.id },
      include: {
        model: db.Projects,
        as: "projects",
        where: {
          [Op.or]: [
            {
              startAt: {
                [Op.gt]: TODAY_START,
                [Op.lt]: NOW,
              },
            },
            {
              updatedAt: {
                [Op.gt]: TODAY_START,
                [Op.lt]: NOW,
              },
            },
          ],
        },
        include: [
          {
            model: db.Users,
            as: "workers",
            attributes: {
              exclude: [
                "ProjectAssignments",
                "email",
                "password",
                "reset_password_time",
                "reset_password_token",
              ],
            },
          },
          {
            model: db.Hours,
          },
        ],
      },
    });
    console.log(company);
    return res.status(200).json(company.projects);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops! some error occurred",
    });
  }
};
export const getProject = async (req: Request, res: Response) => {
  try {
    const projectID: number = parseInt(req.params.id);
    if (isNaN(projectID))
      return res.status(400).json({ message: "Must be a number" });

    const user: IUser | undefined = req.user;
    if (user === undefined)
      return res.status(401).json({ message: "Must be logged in!" });

    const project = await db.Projects.findOne({
      where: {
        id: projectID,
      },
    });

    if (!project) {
      return res.status(400).json({
        message: "No projects found with this id",
      });
    }

    var worker: boolean = false;

    if (user.projects !== undefined && user.projects.length > 0) {
      const valid = await user.projects?.filter((x) => {
        return x.ProjectId === projectID;
      });
      if (valid === undefined || valid.length === 0) {
        if (user.company === undefined) {
          return res.status(401).json({
            message: "Unauthorized",
          });
        }
        worker = false;
      } else {
        worker = true;
      }
    }

    if (user.company !== undefined && !worker) {
      if (user.company.id !== project.companyId) {
        return res.status(401).json({
          message: "Unauthorized",
        });
      }
    }

    return res.status(200).json(project);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops! some error occurred",
    });
  }
};

export const createProject = async (req: Request, res: Response) => {
  try {
    const user: IUser | undefined = req.user;
    if (user === undefined)
      return res.status(401).json({ message: "Must be logged in!" });
    if (user.company === undefined || user.company === null)
      return res.status(401).json({ message: "Must be in a company!" });

    const { name, startAt, locality } = req.body;

    const data: {
      name: string;
      startAt: Date;
      locality: string;
    } = {
      name: name,
      startAt: startAt,
      locality: locality,
    };

    const company = await db.Companies.findOne({
      where: { id: user.company.id },
    });

    const projects = await company.getProjects();
    if (projects.length >= company.projectsLimit) {
      return res.status(400).json({
        message: "You reach your max projects limit",
      });
    }

    const project = await company.createProject(data);
    if (!project) {
      return res.status(400).json({
        message: "Project already exist",
      });
    }
    return res.status(200).json(project);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops! some error occurred",
    });
  }
};

export const deleteProject = async (req: Request, res: Response) => {
  try {
    const projectID = parseInt(req.params.id);

    const project = await db.Projects.destroy({ where: { id: projectID } });
    if (!project) {
      return res.status(400).json({
        message: "Project not found!",
      });
    }
    return res.status(200).json({
      message: "Project deleted",
    });
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops! some error occurred",
    });
  }
};

export const modifyProject = async (req: Request, res: Response) => {
  try {
    // Need to add ajv schema validator
    const projectID: number = parseInt(req.params.id);
    const name: string = req.body.name;
    const startAt: string = req.body.startAt;
    const locality: string = req.body.locality;

    const user: IUser | undefined = req.user;
    if (user === undefined) {
      return res.status(401).json({
        message: "Must be logged in first!",
      });
    }

    const project: IProject = await db.Projects.findOne({
      where: { id: projectID },
    });
    if (project === null) {
      return res.status(400).json({
        message: "Project not found",
      });
    }

    var worker: boolean = false;

    if (user.projects !== undefined && user.projects.length > 0) {
      const valid = await user.projects?.filter((x) => {
        return x.ProjectId === projectID;
      });
      if (valid === undefined || valid.length === 0) {
        return res.status(401).json({
          message: "Unauthorized",
        });
      }
      worker = true;
    }

    if (user.company !== undefined && !worker) {
      if (user.company.id !== project.companyId) {
        return res.status(401).json({
          message: "Unauthorized",
        });
      }
    }

    const company: ICompany = await project.getCompany();
    if (company.id !== user.company?.id) {
      return res.status(401).json({
        message: "Unauthorized",
      });
    }

    if (!project) {
      return res.status(400).json({
        message: "Project not found",
      });
    }

    project.name = name;
    project.locality = locality;
    project.startAt = new Date().toLocaleDateString();
    project.save();

    return res.status(200).json(project);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops! some error occurred",
    });
  }
};

export const getWorkers = async (req: Request, res: Response) => {
  try {
    const projectID = parseInt(req.params.projectId);
    const project = await db.Projects.findOne({ where: { id: projectID } });
    if (!project) {
      return res.status(400).json({
        message: "Project not found",
      });
    }
    const projectWorkers = await project.getWorkers({
      attributes: ["id", "tag", "firstname", "lastname"],
      include: [
        {
          model: Models.Hours,
          required: false,
          where: {
            ProjectId: projectID,
          },
        },
      ],
    });

    return res.status(200).json(projectWorkers);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops! some error occurred",
    });
  }
};

export const addWorkers = async (req: Request, res: Response) => {
  try {
    // Need validate schema
    const {
      projectId,
      employeesId,
    }: { projectId: number; employeesId: string[] } = req.body;
    console.log(employeesId);
    const company = await db.Companies.findOne({
      where: { id: req.user?.company?.id },
    });

    const employees = await company.getEmployee({
      where: { id: { [Op.in]: employeesId } },
    });

    if (employees.length === 0) {
      return res.status(400).json({
        message: "No employeers id",
      });
    }
    const project = await db.Projects.findOne({
      where: {
        [Op.and]: [
          {
            id: projectId,
            companyId: company.id,
          },
        ],
      },
    });
    if (!project) {
      return res.status(400).json({
        message: "Your company doesn't have this projectId",
      });
    }
    var _projects: Array<{
      ProjectId: number;
      UserId: string;
      name: string;
    }> = [];

    for (var x = 0; x < employees.length; x++) {
      _projects.push({
        ProjectId: project.id,
        name: project.name,
        UserId: employees[x].id,
      });
    }
    try {
      const workers = await db.ProjectAssignments.bulkCreate(_projects);
      var data = [];
      for (var x = 0; x < workers.length; x++) {
        if (workers[x].UserId !== employees[x].id) return;
        data.push({
          id: workers[x].UserId,
          firstname: employees[x].firstname,
          lastname: employees[x].lastname,
          tag: employees[x].tag,
        });
      }
      return res.status(200).json(data);
    } catch (error: Error | any) {
      if (error instanceof Error) {
        logging.info(NAMESPACE, error.message);
      }
      return res.status(500).json({
        message: "Assignment already exist!",
      });
    }
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops! some error occurred, maybe assignment already exist",
    });
  }
};

export const deleteWorker = async (req: Request, res: Response) => {
  try {
    const { projectId, employeeId } = req.body;
    const projectAssignment = await db.ProjectAssignments.findOne({
      where: {
        [Op.and]: [
          {
            UserId: employeeId,
            ProjectId: projectId,
          },
        ],
      },
    });

    if (!projectAssignment) {
      return res.status(400).json({
        message: "Project or employee not found!",
      });
    }

    const destroy = await projectAssignment.destroy();
    return res.status(200).json(destroy);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops! some error occurred",
    });
  }
};

export const getHours = async (req: Request, res: Response) => {
  try {
    const projectID: number = parseInt(req.params.projectId);

    const hours = await db.Hours.findAll({
      where: { ProjectId: projectID },
    });

    if (!hours) {
      return res.status(400).json({ message: "No project found" });
    }
    return res.status(200).send(hours);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Invalid input",
    });
  }
};

export const addHours = async (req: Request, res: Response) => {
  try {
    // TODO: add ajv validator
    const projectID: number = req.body.projectId;
    const workerID: string = req.body.workerId;
    const userHours: number = req.body.hours;
    const companyID: number | undefined = req.user?.company?.id;

    const project = await db.Projects.findOne({
      where: { id: projectID },
      attributes: {
        include: "companyId",
      },
    });

    if (!project) {
      return res.status(400).json({
        message: "No project found with this id",
      });
    }
    if (project.companyId !== companyID) {
      return res.status(401).json({
        message: "Unauthorized",
      });
    }
    const worker = await project.getWorkers({
      attributes: ["id", "tag", "firstname", "lastname"],
      where: {
        id: workerID,
      },
    });

    if (worker.length === 0 || worker === undefined) {
      return res.status(400).json({
        message: "Worker not exist!",
      });
    }

    const hours = await project.createHour({
      UserId: workerID,
      CompanyId: companyID,
      projectId: projectID,
      Hours: userHours,
    });

    return res.status(200).json({
      hours,
      user: { firstname: worker.firstname, lastname: worker.lastname },
    });
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "OPS, some error occurred",
    });
  }
};

export const addHoursWorker = async (req: Request, res: Response) => {
  try {
    // TODO: add ajv validator
    const projectID: number = req.body.projectId;
    const userHours: number = req.body.hours;
    const workerID: string | undefined = req.user?.id;
    const date: string | undefined = req.body.date;
    if (!workerID)
      return res.status(403).json({ message: "You aren't authorized" });

    const project = await db.Projects.findOne({
      where: { id: projectID },
      attributes: {
        include: "companyId",
      },
    });

    if (!project) {
      return res.status(400).json({
        message: "No project found with this id",
      });
    }

    const worker = await project.getWorkers({
      attributes: ["id", "tag", "firstname", "lastname"],
      where: {
        id: workerID,
      },
    });

    if (worker.length === 0 || worker === undefined) {
      return res.status(400).json({
        message: "Worker not exist!",
      });
    }

    const hours = await project.createHour({
      UserId: workerID,
      CompanyId: project.companyId,
      projectId: projectID,
      Hours: userHours,
      createdAt: date ? new Date(date) : null,
    });
    const user = {
      firstname: worker.firstname,
      lastname: worker.lastname,
    };
    return res.status(200).json({
      hours,
      user,
    });
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "OPS, some error occurred",
    });
  }
};

export const editHours = async (req: Request, res: Response) => {
  try {
    // TODO: add ajv validator
    const projectID: number = req.body.projectId;
    const workerID: string = req.body.workerId;
    const userHours = req.body.hours;
    const user: IUser | undefined = req.user;
    if (user === undefined || user === null) {
      return res.status(401).json({
        message: "Unauthorized!",
      });
    }
    if (user.company === undefined && workerID !== user.id)
      return res.status(400).json({ message: "You need to own the company!" });

    const hours = await db.Hours.findOne({
      where: {
        [Op.and]: [
          {
            UserId: workerID,
            ProjectId: projectID,
          },
        ],
      },
    });
    if (hours === null || hours === undefined) {
      return res.status(400).json({
        message: "Hours not found!",
      });
    }
    hours.Hours = userHours;
    await hours.save();

    if (!hours) {
      return res.status(400).json({
        message: "No hours found with these criteria!",
      });
    }

    return res.status(200).json(hours);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "OPS, some error occurred",
    });
  }
};

export const getNotes = async (req: Request, res: Response) => {
  try {
    const projectID: number = parseInt(req.params.projectId);
    if (isNaN(projectID)) return res.status(400).json({ message: "Bad data" });

    const notes = await db.Notes.findAll({
      where: { ProjectId: projectID },
      include: [
        {
          model: db.Users,
          required: true,
          as: "user",
          attributes: ["id", "tag", "firstname", "lastname"],
        },
      ],
    });
    if (notes === undefined || notes === null) {
      return res.status(400).json({
        message: "Notes not found!",
      });
    }

    return res.status(200).json(notes);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops! some error occurred",
    });
  }
};

export const getNotesDaily = async (req: Request, res: Response) => {
  try {
    const projectID: number = parseInt(req.params.projectId);
    const date: string = req.params.date;
    if (isNaN(projectID)) return res.status(400).json({ message: "Bad data" });
    const TODAY_START = new Date(date).setHours(0, 0, 0, 0);
    const NOW = new Date(date);
    const notes = await db.Notes.findAll({
      where: {
        [Op.and]: [
          {
            createdAt: {
              [Op.gt]: TODAY_START,
              [Op.lt]: NOW,
            },
          },
          {
            ProjectId: projectID,
          },
        ],
      },
      include: [
        {
          model: db.Users,
          required: true,
          as: "user",
          attributes: ["id", "tag", "firstname", "lastname"],
        },
      ],
    });
    if (notes === undefined || notes === null) {
      return res.status(400).json({
        message: "Project not found!",
      });
    }

    return res.status(200).json(notes);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops! some error occurred",
    });
  }
};

export const addNote = async (req: Request, res: Response) => {
  try {
    const projectID: number = req.body.projectID;
    const description: string = req.body.description;
    const user: IUser | undefined = req.user;
    if (user === undefined)
      return res.status(401).json({ message: "Need to be logged in!" });

    const project = await db.Projects.findOne({
      where: { id: projectID },
    });

    if (project === undefined || project === null) {
      return res.status(400).json({
        message: "Project not found!",
      });
    }
    var worker: boolean = false;

    if (user.projects !== undefined && user.projects.length > 0) {
      const valid = await user.projects?.filter((x) => {
        return x.ProjectId === projectID;
      });
      if (
        valid === undefined ||
        (valid.length === 0 && user.company === null)
      ) {
        return res.status(401).json({
          message: "Unauthorized",
        });
      }
      worker = true;
    }

    if (user.company !== undefined && !worker) {
      if (user.company.id !== project.companyId) {
        return res.status(401).json({
          message: "Unauthorized",
        });
      }
    }

    const notes = await project.createNote({
      note: description,
      UserId: user.id,
    });
    const userObj = {
      firstname: user.firstname,
      lastname: user.lastname,
    };
    return res.status(200).json({ notes, user: userObj });
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops! some error occurred",
    });
  }
};

export const deleteNote = async (req: Request, res: Response) => {
  try {
    const noteID: number = parseInt(req.params.id);
    const user: IUser | undefined = req.user;
    if (user === undefined || user === null) {
      return res.status(401).json({
        message: "Must be logged in!",
      });
    }
    if (isNaN(noteID)) {
      return res.status(400).json({
        message: "Bad data",
      });
    }

    const note: INote = await db.Notes.findOne({ where: { id: noteID } });
    if (note === undefined || note === null) {
      return res.status(400).json({
        message: "Note not found!",
      });
    }
    const project = await db.Projects.findOne({
      where: { id: note.ProjectId },
      include: "Company",
    });

    if (note.UserId !== user.id && user.company?.id !== project.Company.id) {
      return res.status(401).json({
        message: "Unauthorized",
      });
    }

    await note.destroy();
    return res.status(200).json({ message: "Done" });
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops! some error occurred",
    });
  }
};

export const updateNote = async (req: Request, res: Response) => {
  try {
    const noteID: number = req.body.noteID;
    const description: string = req.body.description;
    const user: IUser | undefined = req.user;

    if (user === undefined || user === null) {
      return res.status(401).json({
        message: "You must be logged in!",
      });
    }

    const note = await db.Notes.findOne({ where: { id: noteID } });

    if (note === undefined || note === null) {
      return res.status(400).json({
        message: "Note not found!",
      });
    }

    if (
      note.UserId !== user.id &&
      user.company !== undefined &&
      !user.company.isStaff &&
      !user.isStaff
    ) {
      return res.status(401).json({
        message: "You can't modify this",
      });
    }

    note.description = description;
    await note.save();
    return res.status(200).json(note);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops! some error occurred",
    });
  }
};

export const getDailyWorkersProject = async (req: Request, res: Response) => {
  try {
    if (req.params.projectId === "")
      return res.status(400).json({ message: "Missing id" });

    const projectId: number = parseInt(req.params.projectId);
    const project = await db.Projects.findOne({
      where: { id: projectId },
    });
    if (!project) {
      return res.status(400).json({
        message: "No project found with this id",
      });
    }
    const TODAY_START = new Date().setHours(0, 0, 0, 0);
    const NOW = new Date();
    const workersToday = await project.getWorkers({
      attributes: ["id", "firstname", "lastname"],
      include: [
        {
          model: db.Hours,
          required: true,
          where: {
            [Op.and]: [
              {
                createdAt: {
                  [Op.gt]: TODAY_START,
                  [Op.lt]: NOW,
                },
              },
              {
                ProjectId: projectId,
              },
            ],
          },
        },
      ],
    });
    res.send(workersToday);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
      return res.status(500).json({
        message: error.message,
      });
    } else {
      return res.status(500).json({
        message: "Internal server error",
      });
    }
  }
};

export const getMonthlyWorkersProject = async (req: Request, res: Response) => {
  try {
    const projectId: number = req.body.projectId;
    const _month: number = req.body.month;

    const date = new Date();
    date.setMonth(_month + 1);
    var firstDay = new Date(date.getFullYear(), date.getMonth(), 1, 0);
    date.setMonth(_month - 1);
    var lastDay = new Date(date.getFullYear(), date.getMonth() + 1);

    const project = await db.Projects.findOne({
      where: { id: projectId },
    });
    const workers = await project.getWorkers({
      attributes: ["id", "firstname", "lastname", "tag"],
      include: [
        {
          attributes: ["id", "Hours", "ProjectId"],
          model: db.Hours,
          required: true,
          where: {
            createdAt: {
              [Op.between]: [lastDay, firstDay],
            },
          },
        },
      ],
    });
    res.send(workers);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops, some error occurred",
    });
  }
};

export const deleteHours = async (req: Request, res: Response) => {
  try {
    const hoursIds: number[] = req.body.hoursIds;

    if (!hoursIds)
      return res.status(400).json({
        message: "Hours ids is undefined!",
      });

    if (hoursIds.length === 0)
      return res.status(400).json({
        message: "Hoursids min length of 0",
      });

    await db.Hours.destroy({
      where: { id: { [Op.in]: hoursIds } },
    });
    res.sendStatus(200);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
      return res.status(500).json({
        message: error.message,
      });
    } else {
      return res.status(500).json({
        message: "Internal server error",
      });
    }
  }
};

export const deleteWorkerHours = async (req: Request, res: Response) => {
  try {
    const hourId: number = req.body.hourId;
    const user = await db.Users.findOne({
      where: { id: req.user?.id },
    });
    if (!user) {
      return res.status(400).json({
        message: "No user found with this id",
      });
    }
    if (!hourId)
      return res.status(400).json({
        message: "Hours ids is undefined!",
      });

    if (hourId === 0)
      return res.status(400).json({
        message: "Hours id min length of 0",
      });

    const hours = await user.getHours({
      where: { id: hourId },
    });
    if (!hours || hours.length === 0)
      return res.status(401).json({
        message: "Unauthorized",
      });
    await db.Hours.destroy({
      where: {
        id: hours[0].id,
      },
    });

    res.sendStatus(200);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
      return res.status(500).json({
        message: error.message,
      });
    }
    return res.status(500).json({
      message: "Ops internal server error",
    });
  }
};

export const fakeHoursDaily = async (req: Request, res: Response) => {
  try {
    // TODO: add ajv validator
    const projectID: number = req.body.projectId;
    const userHours: number = req.body.hours;
    const workerID: string | undefined = req.body.workerId;
    const date: string | undefined = req.body.date;

    const project = await db.Projects.findOne({
      where: { id: projectID },
      attributes: {
        include: "companyId",
      },
    });

    if (!project) {
      return res.status(400).json({
        message: "No project found with this id",
      });
    }

    const worker = await project.getWorkers({
      attributes: ["id", "tag", "firstname", "lastname"],
      where: {
        id: workerID,
      },
    });

    if (worker.length === 0 || worker === undefined) {
      return res.status(400).json({
        message: "Worker not exist!",
      });
    }

    const hours = await project.createHour({
      UserId: workerID,
      CompanyId: project.companyId,
      projectId: projectID,
      Hours: userHours,
      createdAt: date ? new Date(date) : null,
    });

    await hours.destroy();
    const user = {
      firstname: worker.firstname,
      lastname: worker.lastname,
    };
    return res.status(200).json({
      hours,
      user,
    });
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "OPS, some error occurred",
    });
  }
};

export const getWorkerProject = async (req: Request, res: Response) => {
  try {
    if (!req.user?.projects) return res.status(200).json({});
    const projectsIds = req.user?.projects?.map((item: any) => item.ProjectId);
    if (!projectsIds) return res.status(200).json({ message: "" });
    const projects = await db.Projects.findAll({
      where: {
        id: {
          [Op.in]: projectsIds,
        },
      },
    });

    return res.status(200).json(projects);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops! some error occurred",
    });
  }
};

export const getWorkerProjectDaily = async (req: Request, res: Response) => {
  try {
    if (!req.user?.projects) return res.status(200).json({});
    const date: string = req.params.date;
    const TODAY_START = new Date(date).setHours(0, 0, 0, 0);
    const NOW = new Date(date);
    const projectsIds = req.user?.projects?.map((item: any) => item.ProjectId);
    if (!projectsIds) return res.status(200).json({ message: "" });
    const projects = await db.Projects.findAll({
      where: {
        [Op.or]: [
          {
            startAt: {
              [Op.gt]: TODAY_START,
              [Op.lt]: NOW,
            },
          },
          {
            updatedAt: {
              [Op.gt]: TODAY_START,
              [Op.lt]: NOW,
            },
          },
        ],
        id: {
          [Op.in]: projectsIds,
        },
      },
      include: [
        {
          model: db.Users,
          as: "workers",
          attributes: {
            exclude: [
              "ProjectAssignments",
              "email",
              "password",
              "reset_password_time",
              "reset_password_token",
            ],
          },
        },
        {
          model: db.Hours,
        },
      ],
    });

    return res.status(200).json(projects);
  } catch (error: Error | any) {
    if (error instanceof Error) {
      logging.info(NAMESPACE, error.message);
    }
    return res.status(500).json({
      message: "Ops! some error occurred",
    });
  }
};
