import updateRole from './user/updateRole';
import getTokenPassword from './user/getTokenPassword';
import resetPassword from './user/resetPassword';
import changePassword from './user/changePassword';
import login from './user/login';
import register from './user/register';

export default {
    changePassword,
    updateRole,
    getTokenPassword,
    resetPassword,
    login,
    register,
};
