import Ajv from "ajv";
import addFormats from "ajv-formats";
import ajvErrors from "ajv-errors";

const ajv = new Ajv({ allErrors: true });
addFormats(ajv);
ajvErrors(ajv);

export default ajv.compile({
  $schema: "http://json-schema.org/draft-07/schema",
  type: "object",
  title: "User Register paylaod",
  default: {},
  required: ["firstname", "lastname", "email", "password"],
  properties: {
    firstname: {
      $id: "#/properties/firstname",
      type: "string",
      title: "Firstname prop",
      description: "User firstname.",
      minLength: 3,
      maxLength: 255,
      errorMessage: "Firstname must be min 3 char",
    },
    lastname: {
      $id: "#/properties/lastname",
      type: "string",
      title: "Lastname prop",
      description: "User lastname.",
      minLength: 3,
      maxLength: 255,
      errorMessage: "Lastname must be min 3 char",
    },
    email: {
      $id: "#/properties/email",
      format: "email",
      type: "string",
      title: "Email prop",
      minLength: 3,
      maxLength: 255,
      description: "User Email.",
      errorMessage: "Email is in wrong format",
    },
    password: {
      $id: "#/properties/password",
      type: "string",
      minLength: 1,
      maxLength: 255,
      pattern: "^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])(?=.{8,})",
      title: "Password prop.",
      description: "User password.",
      errorMessage:
        "Password must be 8char long, 1 Upper case, 1 Number, 1 Symbol",
    },
    additionalProperties: false,
  },
});
