import Ajv from "ajv";
import addFormats from "ajv-formats";
import ajvErrors from "ajv-errors";

const ajv = new Ajv({ allErrors: true });
addFormats(ajv);
ajvErrors(ajv);

export default ajv.compile({
  $schema: "http://json-schema.org/draft-07/schema",
  $id: "http://example.com/example.json",
  type: "object",
  title: "Update user role payload",
  default: {},
  examples: [
    {
      id: 1,
      role: "admin",
    },
  ],
  required: ["id", "role"],
  properties: {
    id: {
      $id: "#/properties/id",
      type: "string",
      title: "user ID",
      default: 0,
      minLength: 5,
      maxLength: 50,
      examples: [1],
    },
    role: {
      $id: "#/properties/role",
      type: "string",
      enum: ["admin", "user"],
      title: "User new role",
      description: "admin, user etc",
      minLength: 1,
      maxLength: 10,
      examples: [1],
    },
  },
  additionalProperties: false,
});
