import Ajv from "ajv";
import addFormats from "ajv-formats";
import ajvErrors from "ajv-errors";

const ajv = new Ajv({ allErrors: true });
addFormats(ajv);
ajvErrors(ajv);

export default ajv.compile({
  $schema: "http://json-schema.org/draft-07/schema",
  type: "object",
  title: "Reset password",
  default: {},
  examples: [
    {
      password: "!Yo0uR5u$p3rP0as55",
    },
  ],
  required: ["password"],
  properties: {
    password: {
      $id: "#/properties/password",
      type: "string",
      minLength: 8,
      maxLength: 255,
      pattern: "^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])(?=.{8,})",
      title: "Password prop.",
      description: "User password.",
      errorMessage:
        "Password must be 8char long, 1 Upper case, 1 Number, 1 Symbol",
    },
  },
  additionalProperties: false,
});
