import Ajv from "ajv";
import addFormats from "ajv-formats";
import ajvErrors from "ajv-errors";

const ajv = new Ajv({ allErrors: true });
addFormats(ajv);
ajvErrors(ajv);

export default ajv.compile({
  $schema: "http://json-schema.org/draft-07/schema",
  type: "object",
  title: "Get token for reset your password",
  default: {},
  examples: [
    {
      email: "youemail@example.com",
    },
  ],
  required: ["email"],
  properties: {
    email: {
      $id: "#/properties/email",
      type: "string",
      title: "User email",
      default: "",
      examples: ["youemail@example.com"],
      format: "email",
      minLength: 5,
      maxLength: 255,
    },
  },
  additionalProperties: false,
});
