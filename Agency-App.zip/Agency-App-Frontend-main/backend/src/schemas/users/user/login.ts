import Ajv from "ajv";
import addFormats from "ajv-formats";
import ajvErrors from "ajv-errors";

const ajv = new Ajv({ allErrors: true });
addFormats(ajv);
ajvErrors(ajv);

export default ajv.compile({
  $schema: "http://json-schema.org/draft-07/schema",
  type: "object",
  title: "User login paylaod",
  default: {},
  required: ["email", "password"],
  properties: {
    email: {
      $id: "#/properties/username",
      type: "string",
      minLength: 4,
      maxLength: 255,
      title: "Email",
      format: "email",
      description: "User Email.",
      errorMessage: "Email must be min 4 char",
    },
    password: {
      $id: "#/properties/password",
      type: "string",
      minLength: 6,
      maxLength: 255,
      pattern: "^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])(?=.{6,})",
      title: "Password prop.",
      description: "User password.",
      errorMessage:
        "Password must be 8char long, 1 Upper case, 1 Number, 1 Symbol",
    },
  },
  additionalProperties: false,
});
