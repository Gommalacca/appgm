// TODO
import Ajv from 'ajv';

const ajv = new Ajv({ allErrors: true });

export default ajv.compile({});
