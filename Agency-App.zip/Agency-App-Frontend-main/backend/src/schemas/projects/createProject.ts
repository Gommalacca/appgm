import Ajv from "ajv";

const ajv = new Ajv({ allErrors: true });

export default ajv.compile({
  $schema: "http://json-schema.org/draft-07/schema",
  $id: "http://example.com/example.json",
  type: "object",
  title: "Create company",
  description: "Payload for creating a company.",
  default: {},
  examples: [
    {
      name: "Test",
      startAt: "test",
      locality: "Lucca",
    },
  ],
  required: ["name", "startAt", "locality"],
  properties: {
    name: {
      $id: "#/properties/name",
      type: "string",
      title: "Porject Name",
      default: "",
      minLength: 2,
      maxLength: 255,
      examples: ["Test"],
    },
    startAt: {
      $id: "#/properties/startAt",
      type: "string",
      title: "Start at",
      description: "When the project is created.",
      default: "",
      minLength: 2,
      maxLength: 255,
      examples: ["14/05/2020"],
    },
    locality: {
      $id: "#/properties/locality",
      type: "string",
      title: "Locality",
      minLength: 2,
      maxLength: 255,
      description: "Where the project is created.",
      default: "",
      examples: ["Francia"],
    },
  },
  additionalProperties: false,
});
