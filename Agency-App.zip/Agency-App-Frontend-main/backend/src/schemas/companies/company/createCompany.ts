import Ajv from 'ajv';

const ajv = new Ajv({ allErrors: true });

export default ajv.compile({
    $schema: 'http://json-schema.org/draft-07/schema',
    $id: 'http://example.com/example.json',
    type: 'object',
    title: 'Create company',
    description: 'Payload for creating a company.',
    default: {},
    examples: [
        {
            name: 'Test',
            projectLimits: 10
        }
    ],
    required: ['name', 'projectsLimit'],
    properties: {
        name: {
            $id: '#/properties/name',
            type: 'string',
            title: 'Company name',
            default: '',
            examples: ['Test']
        },
        projectsLimit: {
            $id: '#/properties/projectsLimit',
            type: 'integer',
            title: 'Projects limit',
            description: 'How many project he can create.',
            default: 0,
            examples: [10]
        }
    },
    additionalProperties: false
});
