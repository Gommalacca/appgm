import Ajv from "ajv";

const ajv = new Ajv({ allErrors: true });

export default ajv.compile({
  $schema: "http://json-schema.org/draft-07/schema",
  $id: "http://example.com/example.json",
  type: "object",
  title: "Add employee",
  default: {},
  examples: [
    {
      userID: 1,
    },
  ],
  required: ["userID"],
  properties: {
    userID: {
      $id: "#/properties/userID",
      type: "string",
      title: "userID",
      description: "UUID.",
      default: "0",
      minLength: 5,
      maxLength: 50,
      examples: ["0"],
    },
  },
  additionalProperties: false,
});
