import createCompany from './company/createCompany';

export default {
    createCompany
}