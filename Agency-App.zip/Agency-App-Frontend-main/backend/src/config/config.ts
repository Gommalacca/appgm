import dotenv from "dotenv";

dotenv.config();

const SERVER_PORT = process.env.SERVER_PORT || 3000;
const SERVER_HOSTNAME = process.env.SERVER_HOSTNAME || "localhost";
const SERVER_ENV = process.env.NODE_ENV || "development"; // Environment state ( development, staging, production)
const SERVER_VERBOSE = process.env.SERVER_VERBOSE || "true";
const SERVER_DB_AUTOFILL = process.env.DB_AUTOFILL || "true";
const SERVER_DB_FORCERESET = process.env.DB_FORCERESET || "false";
const SERVER_TOKEN_ISSUER = process.env.SERVER_TOKEN_ISSUER || "imcool";
const SERVER_TOKEN_SECRET = process.env.SERVER_TOKEN_SECRET || "test$%&/";
const SERVER_TOKEN_EXPIRETIME = process.env.SEVER_TOKEN_EXPIRETIME || 3600;
const SERVER = {
  port: SERVER_PORT,
  hostname: SERVER_HOSTNAME,
  token: {
    expireTime: SERVER_TOKEN_EXPIRETIME,
    issuer: SERVER_TOKEN_ISSUER,
    secret: SERVER_TOKEN_SECRET,
  },
  env: SERVER_ENV,
  verbose: SERVER_VERBOSE,
  database: {
    autoFill: SERVER_DB_AUTOFILL,
    forceReset: SERVER_DB_FORCERESET,
  },
};

const config = {
  server: SERVER,
};

export default config;
