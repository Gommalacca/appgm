export enum rules {
    user,
    admin
}
