export const MonthEN = [
  { value: "0", label: "January" },
  { value: "1", label: "February" },
  { value: "2", label: "March" },
  { value: "3", label: "April" },
  { value: "4", label: "May" },
  { value: "5", label: "June" },
  { value: "6", label: "July" },
  { value: "7", label: "August" },
  { value: "8", label: "September" },
  { value: "9", label: "October" },
  { value: "10", label: "November" },
  { value: "11", label: "December" },
];

export const MonthIT = [
  { value: "0", label: "Gennaio" },
  { value: "1", label: "Febbraio" },
  { value: "2", label: "Marzo" },
  { value: "3", label: "Aprile" },
  { value: "4", label: "Maggio" },
  { value: "5", label: "Giugno" },
  { value: "6", label: "Luglio" },
  { value: "7", label: "Agosto" },
  { value: "8", label: "Settembre" },
  { value: "9", label: "Ottobre" },
  { value: "10", label: "Novembre" },
  { value: "11", label: "Dicembre" },
];
