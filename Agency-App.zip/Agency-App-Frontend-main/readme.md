# Setup Local env

## Start postgres test db

> $ docker run --name some-postgres -e POSTGRES_PASSWORD=postgres -p 5432:5432 -d postgres

## Start backend service

> $ npm run dev

## Start frontend

> $ npm start
